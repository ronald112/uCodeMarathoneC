#include "libmx.h"

bool mx_isupper(int c) {
    return c > 64 && c < 91;
}
